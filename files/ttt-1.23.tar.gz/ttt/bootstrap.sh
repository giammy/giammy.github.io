SUBDIRS="bmlib ttt"
for i in $SUBDIRS; do rm -f $i/.depend; touch $i/.depend; done

autoheader
automake --add-missing
aclocal
autoconf

#rm -rf LINUX WIN32
#mkdir LINUX WIN32
#(cd LINUX; ../configure)
#(cd LINUX; make depend)
#(cd WIN32; ../configure --enable-gui --host=i386-cygwin32 --build=i386-linux)

# for linux:
# ./configure

# for windows:
# ./configure --host=i386-cygwin32 --build=i386-linux
