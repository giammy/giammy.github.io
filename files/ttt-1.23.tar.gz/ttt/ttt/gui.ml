(*
 * This file is part of TicTacTic --- Copyright (c) 2000 Gianluca Moro
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *)

open Thcheme
open Configuration
open Language
open Tk
open Bm_menu
open Bm_glue
open Global

let (quitShowInterest, quitNotify) = Chatterbox.create ()

let dump_preferences parent () =
  try
    Configuration.dump vConfFile
  with Configuration.Error ->
    ignore (Bm_errormsg.make
	      { english = "Cannot write preferences to disk";
		italiano = "Errore durante la registrazione delle preferenze" }
	      (fun () -> ())
	      parent)

let showAuthor parent =
  ignore (Bm_errormsg.makeWithTitle
	    { english = "Author"; italiano = "Autore"}
	    { english = 
	      "********************************************************\n" ^
	      "\nGianluca Moro\ngiammy@artemide.dei.unipd.it\n" ^
	      "\nFor updates and news:\n" ^ 
	      "www.giammy.com\nor\ntictactic.sourceforge.net\n" ^
	      "\n********************************************************"; 
	      italiano = 
	      "********************************************************\n" ^
	      "\nGianluca Moro\ngiammy@artemide.dei.unipd.it\n" ^
	      "\nPer aggiornamenti o informazioni:\n" ^
	      "www.giammy.com\no\ntictactic.sourceforge.net\n" ^
	      "\n********************************************************"; 
	    } 
	    (fun s -> ()) parent)

let enne = string_of_int Global.boardSize
let emme = string_of_int Global.cellLife

let showRules parent = 
  ignore (Bm_errormsg.makeWithTitle
	    { english = "Game Rules"; italiano = "Regole del gioco"}
	    { english = 
	      "************************************************************\n"^
	      "\nTicTacTic is played on a square board of size "^enne^"\n" ^
	      "\neach player must try to align "^emme^" cells of his color\n" ^
	      "horizontally, vertically or diagonally\n" ^
	      "\neach player can occupy at most " ^ emme ^ " cell:\n" ^
	      "occupying one more cell, removes the oldest one\n" ^
	      "\nFor updates and news:\n" ^ 
	      "www.giammy.com\nor\ntictactic.sourceforge.net\n" ^
	      "\n************************************************************";

	      italiano = 
	      "************************************************************\n"^
	      "\nTicTacTic si gioca su una tabella quadrata di lato " ^ enne ^
	      "\n" ^
	      "\nciascun giocatore deve allineare " ^ emme ^ 
	      " caselle del suo colore\n" ^
	      "in orizzontale, verticale o diagonale\n" ^
	      "\nciascun giocatore puo' occupare al massimo " ^ emme ^ 
	      " caselle\n" ^
	      "occupandone una in piu', la piu' vecchia viene rimossa\n" ^
	      "\nPer aggiornamenti o informazioni:\n" ^
	      "www.giammy.com\no\ntictactic.sourceforge.net\n" ^
	      "\n************************************************************";
	    } 
	    (fun s -> ()) parent)

let createMainMenu parent =

  let fileMenu = [
    MenuEntry ({english = "New game"; italiano = "Nuovo gioco"},
	       (fun () -> Board.resetGame ()));
    MenuSeparator;
    MenuEntry ({english = "Quit"; italiano = "Esci"},
	       quitNotify)
  ] and

  preferencesMenu = [
    MenuDisabled ({english = "Select Player"; 
		    italiano = "Seleziona i giocatori"});
    MenuRadioButton ({ english = "Computer plays " ^ 
		       (getConfigurationEnglishString vWhiteColor); 
		       italiano = "Il computer gioca con il " ^
		       (getConfigurationItalianString vWhiteColor)},
		     vComputerPlayer,
		     Integer 1);
    MenuRadioButton ({ english = "Computer plays " ^ 
		       (getConfigurationEnglishString vBlackColor); 
		       italiano = "Il computer gioca con il " ^
		       (getConfigurationItalianString vBlackColor) },
		     vComputerPlayer,
		     Integer 2);
    MenuRadioButton ({ english = "2 players";
		       italiano = "2 giocatori" },
		     vComputerPlayer,
		     Integer 0);

    MenuSeparator;
    MenuDisabled ({english = "Select Level"; 
		    italiano = "Seleziona il Livello"});
    MenuRadioButton ({ english = "Beginner"; 
		       italiano = "Base" },
		     vComputerLevel,
		     Integer 0);
    MenuRadioButton ({ english = "Novice"; 
		       italiano = "Facile" },
		     vComputerLevel,
		     Integer 2);
    MenuRadioButton ({ english = "Easy";
		       italiano = "Normale" },
		     vComputerLevel,
		     Integer 4);
    MenuRadioButton ({ english = "Average";
		       italiano = "Medio" },
		     vComputerLevel,
		     Integer 6);
    MenuRadioButton ({ english = "Good";
		       italiano = "Buono" },
		     vComputerLevel,
		     Integer 8);
    MenuRadioButton ({ english = "Expert";
		       italiano = "Esperto" },
		     vComputerLevel,
		     Integer 10);
    MenuRadioButton ({ english = "Hard";
		       italiano = "Difficile" },
		     vComputerLevel,
		     Integer 12);
    MenuRadioButton ({ english = "Master";
		       italiano = "Maestro" },
		     vComputerLevel,
		     Integer 14);
(*
    MenuSeparator;
    MenuCheckButton ({ english = "Show Cell Age"; 
		       italiano = "Mostra l'eta' delle celle" },
		     vShowAging);
*)
    MenuSeparator;
    MenuDisabled ({english = "Select language"; 
		    italiano = "Seleziona lingua"});
    MenuRadioButton ({ english = "English"; italiano = "English" },
		     Language.variable,
		     Language.sEnglish);
    MenuRadioButton ({ english = "Italiano";
		       italiano = "Italiano" },
		     Language.variable,
		     Language.sItaliano);

    MenuSeparator;
    MenuCheckButton ({ english = "Tear-off menus"; 
		       italiano = "Menu separabili" },
		     vTearOff);

    MenuSeparator;
    MenuEntry ({english = "Save Preferences"; 
		 italiano = "Registra Preferenze"},
	       dump_preferences parent);
  ] and

  helpMenu = [
    MenuEntry ({english = "Author"; italiano = "Autori"},
	       (fun () -> showAuthor parent));
    MenuEntry ({english = "Game Rules"; italiano = "Regole del Gioco"},
	       (fun () -> showRules parent))
  ] in
  begin

    Modeline.newGame ();
    Bm_menu.create parent
      [
	({english = "Game"; italiano = "Gioco"},
	 [UnderlinedChar (-1)], Side_Left, fileMenu);

	({english = "Preferences"; italiano = "Preferenze"},
	 [UnderlinedChar (-1)], Side_Left, preferencesMenu);

	({english = "Help"; italiano = "Aiuto"},
	 [UnderlinedChar (-1)], Side_Right, helpMenu);
      ]	
  end

let make top =
  Bm_vbox.topExpanding 
    (pair
       (Bm_vbox.bottomExpanding
	  (pair
	     createMainMenu 
	     Board.make
	  ))
       Modeline.make)
    top


