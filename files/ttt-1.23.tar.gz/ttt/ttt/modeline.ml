open Bm_glue
open Tk
open Language

let (showInterest, notify) = Chatterbox.create ()

let default_options = [
  Relief Sunken;
  BorderWidth (Pixels 2)
] 

let make parent =
  let (l, reconfigure) = Bm_emptylabel.makeWithOptions default_options parent
  and current_msg = ref { english = ""; italiano = "" }
  in begin
    showInterest 
      (protect 
	 (fun msg ->
	   current_msg := msg;
	   reconfigure (translate msg) "" ""));

    withTranslationF (fun () -> !current_msg) (fun s -> reconfigure s "" "");

    l
  end

let emme = string_of_int Global.cellLife

let newGame () = notify { english = "Align " ^ emme ^ 
			  " cells with the same color"; 
			  italiano = "Allinea " ^ emme ^ 
			  " caselle dello stesso colore"}


