(*
 * This file is part of TicTacTic --- Copyright (c) 2000 Gianluca Moro
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *)

open Tk
open Thcheme
open Configuration

let version = "v1.23"
 
let vGeometry = Configuration.create (intern "geometry") 
    (String "350x350")

let linuxPath = [
  Configuration.EnvRelative ("HOME", "/.tttrc");
  Configuration.ExecRelative "/tttrc";
  Configuration.Absolute "/etc/tttrc";
] 

let winPath = [
  Configuration.Absolute "./ttt.rc";
  Configuration.Absolute "\\windows\\ttt.rc";
] 

let path () = 
  match Sys.os_type with
  | "Unix" -> linuxPath
  | "Win32" -> winPath
  | _ -> []

let sConfFile = intern "configuration-file"
let vConfFile = Configuration.create sConfFile 
    (String (Configuration.toAbsolute (List.hd (path()))))

let _ = Configuration.boot (path ()) 
    (fun s -> Configuration.set vConfFile (String s));
    
type player =
  | WhitePlayer
  | BlackPlayer
  | NoPlayer

type status =
  | UpToWhite
  | UpToBlack
  | WinnerWhite
  | WinnerBlack

type cell = {
    contents : player;
    life : int;
  } 

let vboardSize = Configuration.create (intern "board-size")
    (Integer 3)

let vCellLife = Configuration.create (intern "cell-to-align")
    (Integer 3)

let vWhiteColor = Configuration.create (intern "white-color")
    (String "white")

let vBlackColor = Configuration.create (intern "black-color")
    (String "red")

let vEmptyColor = Configuration.create (intern "empty-color")
    (String "grey80")

let vComputerLevel = Configuration.create (intern "computer-level")
    (Integer 8)

let vComputerPlayer = Configuration.create (intern "computer-player")
    (Integer 2)

let vWinningMoveValue = Configuration.create (intern "winning-move-value")
    (Integer 100)

let vNeutralMoveValue = Configuration.create (intern "neutral-move-value")
    (Integer 0)

let vShowAging = Configuration.create (intern "show-aging") False

let getConfigurationBool x = withBool (Configuration.get x) (fun v -> v)
let getConfigurationInteger x = withInteger (Configuration.get x) (fun v -> v)
let getConfigurationString x = withString (Configuration.get x) (fun v -> v)

let whiteColor = getConfigurationString vWhiteColor
let blackColor = getConfigurationString vBlackColor
let emptyColor = getConfigurationString vEmptyColor

let translationTable = [
  "black", "nero"; 
  "grey", "grigio";
  "gray", "grigio";
  "white", "bianco"; 
  "red", "rosso"; 
  "yellow", "giallo";
  "green", "verde"; 
  "blue", "blu";
  "snow", "bianco";
  "shell", "grigio";
  "lemon", "giallo";
  "rosy", "rosa";
  "rose", "rosa";
  "tan", "marrone";
  "orange", "arancio";
  "pink", "rosa";
  "azure1", "azzurro";
  "sienna", "marrone";
  "rod", "marrone";
  "gold", "giallo";
  "brown", "marrone"; 
  "chartreuse", "verde";
  "olive", "verde";
  "brick", "rosso";
  "fire", "rosso";
  "salmon", "salmone";
  "cyan", "azzurro";
  "marine", "verde";
  "turquoise", "azzurro";
  "khaki", "cachi";
  "blush", "grigio";
  "honeydew", "grigio";
  "ivory", "grigio";
  "chocolate", "marrone";
  "tomato", "rosso";
  "bisque", "marrone";
  "peachpuff", "marrone";
  "cornsilk", "grigio";
  "burlywood", "marrone";
  "wheat", "grigio";
  "coral", "marrone";
  "maroon", "ciclamino";
  "plum", "magenta";
  "magenta", "magenta";
  "orchid", "viola";
  "purple", "blu";
  "thistle", "grigio";
] 

let getConfigurationEnglishString = getConfigurationString

let isSubstring mainString subString =
  let subStringLength = String.length subString in
  let rec loop m =
    let mLength = String.length m in
    if (mLength < subStringLength) then false
    else
      begin
	if ((String.sub m 0 subStringLength) = subString) then true
	else loop (String.sub m 1 (mLength - 1))
      end
  in
  loop mainString

let getConfigurationItalianString v = 
  let englishString = getConfigurationString v in
  let isInGivenString = isSubstring (String.lowercase englishString) in
  let isInGivenStringLower s = isInGivenString (String.lowercase s) in
  let rec search = function
    | [] -> englishString
    | (e, i) :: t -> if (isInGivenStringLower e) then i else search t in
  search translationTable

let boardSize = getConfigurationInteger vboardSize
let cellLife = 
  let c = getConfigurationInteger vCellLife in
  if c <= boardSize then c else boardSize

let computerLevel () = getConfigurationInteger vComputerLevel
let winningMoveValue () = getConfigurationInteger vWinningMoveValue
let neutralMoveValue () = getConfigurationInteger vNeutralMoveValue

let computerPlayer () = 
  let s = getConfigurationInteger vComputerPlayer in
  if s = 1 
  then WhitePlayer
  else 
    begin
      if s = 2
      then BlackPlayer
      else NoPlayer
    end

let alignCombination = ref (Some
  [
    [0;1;2]; [3;4;5]; [6;7;8];
    [0;3;6]; [1;4;7]; [2;5;8];
    [0;4;8]; [2;4;6];
  ] )

let _ = alignCombination := None

let iota = 
  let rec loop l i =
    if (i = 0) then 
      l
    else loop ((i - 1) :: l) (i - 1)
  in loop []
