(*
 * This file is part of TicTacTic --- Copyright (c) 2000 Gianluca Moro
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *)

open Tk
open Global 

(* hash table will be present in next revision
module HashBoard =
  struct
    type t = (player * int) array
    let equal = (=)
    let hash b = 
      let base = cellLife * 2 in
      let rec loop current n = 
	if n >= 0 then
	  begin
	    let recode (p, a) =  
	      if p = WhitePlayer then (2 * a)
	      else if p = BlackPlayer then (2 * a - 1)
	      else 0
	    in
	    loop (base * current + (recode (Array.get b n))) (n-1)
	  end
	else
	  current
      in Hashtbl.hash (loop 0 ((Array.length b) - 1)) 
  end

module HashtblBoard = Hashtbl.Make(HashBoard)
      
let hashTable = HashtblBoard.create 71
*)
(*
 * a debug printout
 *)
let ascii_print board =
  let print_color c =
    print_string
      (match c with
      | WhitePlayer -> "WHITE "
      | BlackPlayer -> "BLACK "
      | NoPlayer -> "NONE ");
  in
  begin
    Array.iteri
      (fun n (player, remaining) -> 
	print_color player;
	Printf.printf "%d " remaining;
	if (n mod boardSize = (boardSize-1)) then print_string "\n";
      ) board;
    flush stdout;
  end


(*
 * check for a winner combination: an aligned row, column or diagonal
 *)
let getAlignCombination () =
  match !alignCombination with
  | None ->
      begin
	let horizontalSequence row fromCol =
	  List.map (fun n -> fromCol + (row * boardSize) + n) 
	    (iota cellLife)
	in
	let verticalSequence col fromRow =
	  List.map (fun n -> fromRow * boardSize + col + boardSize * n) 
	    (iota cellLife)
	in
	let allHVSequences direction pos =
	  List.map (fun fc -> direction pos fc) 
	    (iota (boardSize - cellLife + 1))
	in

	let diagonalLR op row col =
	  List.map (fun n -> row * boardSize + col + n * (op boardSize 1)) 
	    (iota cellLife)
	in
	let diagonalRight = diagonalLR (+) in
	let diagonalLeft = diagonalLR (-) in
	let allDiagonalRight () = 
	  List.flatten
	    (List.map 
	       (fun r -> 
		 List.map 
		   (fun c -> diagonalRight r c) 
		   (iota (boardSize - cellLife + 1))
	       ) (iota (boardSize - cellLife + 1)))
	in
	let allDiagonalLeft () = 
	  List.flatten
	    (List.map 
	       (fun r -> 
		 List.map 
		   (fun c -> diagonalLeft r (boardSize - c - 1)) 
		   (iota (boardSize - cellLife + 1))
	       ) (iota (boardSize - cellLife + 1)))
	in

	let allHorizontalSequences = allHVSequences horizontalSequence in
	let allVerticalSequences = allHVSequences verticalSequence in

	((List.flatten (List.map allHorizontalSequences (iota boardSize))) @
	(List.flatten (List.map allVerticalSequences (iota boardSize))) @
	(allDiagonalLeft ()) @
	(allDiagonalRight ()))
      end
  | Some x -> x

let rec isEqual color x =
  match x with
  | [] -> true
  | h :: t -> if color <> h then false else isEqual color t

let isAlignedColor color board =
  let players = Array.map (fun (p, n) -> if n = 0 then (); p) board in
  List.exists 
    (fun x -> isEqual color x)
    (List.map (fun c -> List.map (fun id -> Array.get players id) c ) 
       (getAlignCombination()))

let isWhiteAligned =
  isAlignedColor WhitePlayer

let isBlackAligned =
  isAlignedColor BlackPlayer

let isAligned board =
  if (isWhiteAligned board) 
  then 
    WhitePlayer 
  else
    begin
      if (isBlackAligned board) 
      then 
	BlackPlayer 
      else
	NoPlayer
    end

let getCellPlayer board id =
  let (c, _) = Array.get board id in
  c

let getCellAge board id =
  let (_, remaining) = Array.get board id in
  let x = cellLife - remaining + 1 in
  if x > cellLife 
  then 0
  else x
  
let setCellPlayer board player id = 
  begin
    Array.iteri
      (fun n (cellPlayer, remaining) -> 
	if cellPlayer = player then
	  let rem = remaining - 1 in
	  if rem > 0 then
	    Array.set board n (player, rem)
	  else
	    Array.set board n (NoPlayer, 0)
      ) board;
    Array.set board id (player, cellLife);
  end

let isFree board id =
  if (getCellPlayer board id = NoPlayer)
  then true
  else false

let otherPlayer who =
  match who with
  | WhitePlayer -> BlackPlayer
  | BlackPlayer -> WhitePlayer
  | NoPlayer -> NoPlayer

let buildNewBoard board player id = 
  let l = Array.length board in
  let newb = Array.make l (NoPlayer, cellLife) in
  let _ = Array.blit board 0 newb 0 l in
  let _ = setCellPlayer newb player id in
  newb

let isWinning board player id =
  isAlignedColor player (buildNewBoard board player id)

let selectAll board =
  List.filter (isFree board) (iota (boardSize*boardSize))

let getMax allValue =
  let rec aus max values =
    match values with
    | [] -> max
    | (i, v) :: t -> 
	let (_, m) = List.hd max in 
	if v > m then aus [(i,v)] t 
	else if v = m then aus ((i,v) :: max) t
	else aus max t
  in 
  try
    let maxList = aus [(List.hd allValue)] (List.tl allValue) in
    List.nth maxList (Random.int (List.length maxList))
  with _ -> failwith "Game: getMax of empty list"

let isWinningBoard board player all =
  let rec aus = function
    | [] -> (false, 0)
    | h :: t -> if isWinning board player h then (true, h) else aus t
  in
  aus all

let rec search board player maxLevel lev alpha beta return =
  let all = selectAll board in
  let (isWinner, id) = isWinningBoard board player all in
  if isWinner then
    return id ((winningMoveValue ()) - (2*lev))
  else if lev >= maxLevel then
    return
      (List.nth all (Random.int (List.length all)))
      (neutralMoveValue ())
  else
    let rec loop bestMove alpha = function
      | [] -> return bestMove alpha
      | h :: t ->
	  search (buildNewBoard board player h) 
	    (otherPlayer player) maxLevel (lev + 1) (-beta) (-alpha)
	    (fun _ vvv ->
	      let value = (-vvv) in
	      let (alpha, bestMove) = 
		if (value > alpha) then (value, h) else (alpha, bestMove) in
	      if (alpha >= beta) then 
		begin
		  Tk.update ();
		  return bestMove alpha 
		end
	      else 
		loop bestMove alpha t)
    in
    loop (List.hd all) alpha all

let getNextMove board player =
  search board player (computerLevel ()) 0 (-60000) 60000 
    (fun id _ -> id)

(*
let rec search board player maxLevel lev alpha beta =
  let all = selectAll board player in
  let (isWinner, id) = isWinningBoard board player all in
  if isWinner then
    (id, (winningMoveValue ()) - (2*lev))
  else if lev >= maxLevel then
    (List.nth all (Random.int (List.length all)), neutralMoveValue ())
  else
    begin
      let a = ref alpha in
      let bestMove = ref (List.hd all) in
      let rec loop = function
	| [] -> ()
	| h :: t ->
	    begin
	      let newBoard = buildNewBoard board player h in
	      let value =
		try 
		  HashtblBoard.find hashTable newBoard
		with _ ->
		  begin
		    let (_, vvv) = search newBoard (otherPlayer player) 
			maxLevel (lev + 1) (-beta) (-(!a)) in
		    let v = 0 - vvv in 
		    begin
		      HashtblBoard.add hashTable newBoard v;
		      v
		    end
		  end
	      in
	      if (value > !a) then 
		begin
		  a := value;
		  bestMove := h;
		end;
	      if (!a >= beta) then (Tk.update ()) else loop t
	    end
      in
      begin
	loop all;
	(!bestMove, !a);
      end
    end

let getNextMove board player =
  let (id, _) = search board player (computerLevel ()) 0 (-60000) 60000 in
  id
*)
