(*
 * This file is part of TicTacTic --- Copyright (c) 2000 Gianluca Moro
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *)

open Tk
open Bm_glue
open Language
open Global
open Game

let (boardShowInterest, boardNotify) = Chatterbox.create ()
let (boardUpdateShowInterest, boardUpdateNotify) = Chatterbox.create ()

(*
 * Status of the board
 *)
let board = Array.create (boardSize * boardSize) (NoPlayer, 0) 
let currentPlayer = ref WhitePlayer
let currentStatus = ref UpToWhite

let switchPlayer who =
  who := match !who with
  | WhitePlayer -> currentStatus := UpToBlack; BlackPlayer
  | BlackPlayer -> currentStatus := UpToWhite; WhitePlayer
  | NoPlayer -> NoPlayer

let getCellColor board id = 
  match getCellPlayer board id with
  | WhitePlayer -> whiteColor
  | BlackPlayer -> blackColor
  | NoPlayer -> emptyColor

let getCellDefaultColor board id = 
  match getCellPlayer board id with
  | WhitePlayer -> "white"
  | BlackPlayer -> "red"
  | NoPlayer -> "grey80"

let reportStatus status =
  match status with
  | WinnerWhite -> Modeline.notify 
	{ english = (String.uppercase 
			(getConfigurationEnglishString vWhiteColor) ^ 
	  " WINS!"); 
	  italiano = 
          "IL " ^ (String.uppercase 
		      (getConfigurationItalianString vWhiteColor)) ^ 
          " VINCE!"}
  | WinnerBlack -> Modeline.notify 
	{ english = (String.uppercase 
			  (getConfigurationEnglishString vBlackColor)) ^ 
	  " WINS!"; 
	  italiano = "IL " ^ (String.uppercase 
				(getConfigurationItalianString vBlackColor)) ^
	  " VINCE!"}
  | UpToWhite -> Modeline.notify 
      (if (computerPlayer () = WhitePlayer) then
	{ english = "Computer turn: thinking ..."; 
	  italiano = "La mossa al Computer: un attimo ..."}
      else
	{ english = 
	  (String.lowercase (getConfigurationEnglishString vWhiteColor)) ^
	  " turn..."; 
	  italiano = "La mossa al " ^ 
	  (String.lowercase (getConfigurationItalianString vWhiteColor)) ^
	  "..."})
  | UpToBlack -> Modeline.notify 
      (if (computerPlayer () = BlackPlayer) then
	{ english = "Computer turn: thinking ..."; 
	  italiano = "La mossa al Computer: un attimo ..."}
      else
	{ english = 
	  (String.lowercase (getConfigurationEnglishString vBlackColor)) ^
	  " turn..."; 
	  italiano = "La mossa al " ^ 
	  (String.lowercase (getConfigurationItalianString vBlackColor)) ^
	  "..."})

let positionButton id =
  { Language.english = ""; italiano = "" },
  None,
  (fun k -> boardNotify (id, !currentPlayer); k ())

(*
 * invoke K now and whenever vShowHints variable changes
 *)
let displayAge id =
  let age = getCellAge board id in
  if (getConfigurationBool vShowAging) then
    (if age <> 0 then string_of_int age else "")
  else
    ""
      
let withHints n k =
  let invoke () = k n in 
  begin
    Configuration.showInterest vShowAging (protect (fun _ -> invoke ()));
    invoke ();
  end

let makeRow n p =
  (* make the buttons ... *)
  let bs = 
    try
      Bm_buttons.makeWithOptions 
	[ Background (NamedColor emptyColor); 
	  ActiveBackground (NamedColor emptyColor)]
	(List.map (fun x -> positionButton (x+n)) (iota boardSize)) p 
    with _ ->
      Bm_buttons.makeWithOptions 
	[ Background (NamedColor "grey80"); 
	  ActiveBackground (NamedColor "grey80")]
	(List.map (fun x -> positionButton (x+n)) (iota boardSize)) p 
  in
  (* ... and make them interested in board updates *)
  let _ = List.iter2 
      (fun b x -> boardUpdateShowInterest 
	  (fun () ->
	    try
	      Button.configure b 
		[ Background (NamedColor (getCellColor board (x+n)));
		  ActiveBackground (NamedColor (getCellColor board (x+n)));
		  Text (displayAge (x+n)) ];
	    with _ ->
	      Button.configure b 
		[ Background (NamedColor (getCellDefaultColor board (x+n)));
		  ActiveBackground (NamedColor 
				      (getCellDefaultColor board (x+n)));
		  Text (displayAge (x+n)) ];
	  );
	withHints (x+n) (fun id -> Button.configure b [ Text (displayAge id)])
      ) bs (iota boardSize) 
  in bs

let doMove player id =
  begin
    setCellPlayer board player id;
    switchPlayer currentPlayer;
    boardUpdateNotify ();
    (match Game.isAligned board with
    | WhitePlayer -> currentStatus := WinnerWhite
    | BlackPlayer -> currentStatus := WinnerBlack
    | NoPlayer -> ());
    reportStatus !currentStatus;
    Tk.update();
  end

let checkComputerMove () =
  if (!currentPlayer = (computerPlayer ())) &&
    (!currentStatus = UpToWhite ||
    !currentStatus = UpToBlack) then
    doMove !currentPlayer (getNextMove board !currentPlayer)

let resetGame () =
  begin
    Array.iteri (fun n x -> Array.set board n (NoPlayer, 0)) board;
    currentPlayer := WhitePlayer;
    currentStatus := UpToWhite;
    boardUpdateNotify ();
    Modeline.newGame ();
    reportStatus !currentStatus;
    checkComputerMove ();
  end
      
let make =
  begin
    boardShowInterest (fun (id, player) ->
      if (getCellPlayer board id = NoPlayer) && 
	(!currentStatus <> WinnerWhite) && 
	(!currentStatus <> WinnerBlack) &&
	(computerPlayer() <> player) then
	begin
	  doMove player id ;
	  checkComputerMove ();
	end
      else
	begin
	  Modeline.notify 
	    {english = "INVALID MOVE"; italiano = "MOSSA INVALIDA"}
	end);
    let w = List.map (fun x -> 1.0) (iota boardSize) in
    Bm_grid.make w w (fun p ->
      List.map (fun n -> makeRow (n * boardSize) p) (iota boardSize))
  end

