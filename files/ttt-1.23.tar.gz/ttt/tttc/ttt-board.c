/* $Id: ttt-board.c,v 1.1 2000/11/19 11:10:48 giammy Exp $ */
/*
 * $Log: ttt-board.c,v $
 * Revision 1.1  2000/11/19 11:10:48  giammy
 * added a porting of TicTacTic in C
 *
 * Revision 1.1  2000/11/06 16:24:39  giammy
 * adding GUI to coenc0
 *
 */

#include <assert.h>
#include "ttt.h"
#include "ttt-board.h"

#if BOARD_VECTOR_IMPLEMENTATION

void board_reset(BOARD b)
{
     memset(b, 0, BOARD_SIZE_BYTES);
}

CELL boardGetCell(BOARD b, int id)
{
     return b[id];
}

void boardSetCell(BOARD b, int id, PLAYER p)
{
     int currentId;
     for (currentId = 0; currentId < BOARD_SIZE * BOARD_SIZE; currentId++) {
	  CELL c = boardGetCell(b, currentId);
	  if (currentId == id) {
	       b[id] = CELL_LIFE * p;
	  } else {
	       if ((b[currentId] * p) > 0)
		    b[currentId] -= p;
	  }
     }
}

int board_is_aligned(BOARD b, PLAYER p) 
{
     assert(BOARD_SIZE == 3);      /* TODO */

     if (p > 0) {
	  if ( (b[0] > 0 && b[1] > 0 && b[2] > 0) ||
	       (b[3] > 0 && b[4] > 0 && b[5] > 0) ||
	       (b[6] > 0 && b[7] > 0 && b[8] > 0) ||
	       (b[0] > 0 && b[3] > 0 && b[6] > 0) ||
	       (b[1] > 0 && b[4] > 0 && b[7] > 0) ||
	       (b[2] > 0 && b[5] > 0 && b[8] > 0) ||
	       (b[0] > 0 && b[4] > 0 && b[8] > 0) ||
	       (b[2] > 0 && b[4] > 0 && b[6] > 0)) {
	       return 1;
	  } else
	       return 0;
     } else {
	  if ( (b[0] < 0 && b[1] < 0 && b[2] < 0) ||
	       (b[3] < 0 && b[4] < 0 && b[5] < 0) ||
	       (b[6] < 0 && b[7] < 0 && b[8] < 0) ||
	       (b[0] < 0 && b[3] < 0 && b[6] < 0) ||
	       (b[1] < 0 && b[4] < 0 && b[7] < 0) ||
	       (b[2] < 0 && b[5] < 0 && b[8] < 0) ||
	       (b[0] < 0 && b[4] < 0 && b[8] < 0) ||
	       (b[2] < 0 && b[4] < 0 && b[6] < 0))
	       return 1;
	  else
	       return 0;
     }
}

int isWinningBoard(BOARD b, PLAYER p)
{
     int currentId;
     BOARD newb;

     for (currentId = 0; currentId < BOARD_SIZE*BOARD_SIZE; currentId++) {
	  if (!board_is_Free(b, currentId)) continue;
	  memcpy(newb, b, BOARD_SIZE_BYTES);
	  boardSetCell(newb, currentId, p);
	  if (board_is_aligned(newb, p))
	       return currentId;
     }
     return -1;
}

#endif

#if BOARD_STRUCT_IMPLEMENTATION
void board_reset(BOARD b)
{
     int i;
     memset(b, 0, BOARD_SIZE_BYTES);
     for (i=0; i<CELL_LIFE; i++) {
	  b->white_age[i] = 0xff;
	  b->black_age[i] = 0xff;
     }
}

CELL boardGetCell(BOARD b, int id)
{
     if (b->white_board & (1 << id))
	  return WHITE;
     else if (b->black_board & (1 << id))
	  return BLACK;
     else
	  return NONE;
}

void boardSetCell(BOARD b, int id, PLAYER p)
{
     int ap;
     if (p == WHITE) {
	  ap = b->white_ptr;
	  b->white_board |= (1 << id);
	  b->white_board &= ~(1 << (b->white_age[ap]));
	  b->white_age[ap] = id;
	  ++ap;
	  if (ap >= CELL_TO_ALIGN)
	       ap = 0;
	  b->white_ptr = ap;
     } else {
	  ap = b->black_ptr;
	  b->black_board |= (1 << id);
	  b->black_board &= ~(1 << (b->black_age[ap]));
	  b->black_age[ap] = id;
	  ++ap;
	  if (ap >= CELL_TO_ALIGN)
	       ap = 0;
	  b->black_ptr = ap;
     }
     b->all_board = b->white_board | b->black_board;
}

void boardFastSetCell(BOARD b, int id, PLAYER p) /* DO NOT UPDATE AGE */
{
     if (p == WHITE) {
	  b->white_board |= (1 << id);
     } else {
	  b->black_board |= (1 << id);
     }
     b->all_board = b->white_board | b->black_board;
}

int board_is_aligned(BOARD b, PLAYER p) 
{
     int current;

     assert(BOARD_SIZE == 3);      /* TODO */

     if (p == WHITE)      
	  current = b->white_board;
     else if (p == BLACK)
	  current = b->black_board;
     else
	  return 0;

     if ((current ^ (0x3)) == 0 || 
	 (current ^ (0x3<<3)) == 0 || 
	 (current ^ (0x3<<6)) == 0 ||
	 (current ^ (0x49)) == 0 || 
	 (current ^ (0x49<<1)) == 0 || 
	 (current ^ (0x49<<2)) == 0 ||
	 (current ^ (0x111)) == 0 || 
	 (current ^ (0x54)) == 0 )
	  return 1;
     
     return 0;
}

int isWinningBoard(BOARD b, PLAYER p)
{
     int currentId;
     BOARD newb;

     for (currentId = 0; currentId < BOARD_SIZE*BOARD_SIZE; currentId++) {
	  if (!board_is_Free(b, currentId)) continue;
	  memcpy(newb, b, BOARD_SIZE_BYTES);
	  boardFastSetCell(newb, currentId, p);
	  if (board_is_aligned(newb, p))
	       return currentId;
     }
     return -1;
}

#endif
