/* $Id: ttt-board.h,v 1.1 2000/11/19 11:10:48 giammy Exp $ */
/* 
 * $Log: ttt-board.h,v $
 * Revision 1.1  2000/11/19 11:10:48  giammy
 * added a porting of TicTacTic in C
 *
 * Revision 1.1  2000/11/06 16:24:39  giammy
 * adding GUI to coenc0
 *
 */

#define BOARD_VECTOR_IMPLEMENTATION 1
#define BOARD_STRUCT_IMPLEMENTATION 0

/*
 * , recursion level 14, moving White, answer time is:
 *                        P200 PII400
 * CAML                     5s
 * VECTOR no optimization  11s
 * VECTOR -O2              10s
 * VECTOR loopunroll -O3    6s   3s
 *
 * STRUCT loopunroll -O3    6s  22s
 */

#if BOARD_VECTOR_IMPLEMENTATION
#define WHITE		(+1)
#define BLACK		(-1)
#define NONE            0

typedef int CELL; 
typedef CELL BOARD[BOARD_SIZE * BOARD_SIZE];
typedef int PLAYER;

#define BOARD_SIZE_BYTES (sizeof(CELL) * BOARD_SIZE * BOARD_SIZE)

#define board_switch_player(a) ((a) *=(-1))
#define board_other_player(a) ((a) * (-1))
#define board_is_White(c) (c > 0)
#define board_is_Black(c) (c < 0)
#define board_is_Free(b,c) (b[c] == 0)

#endif

#if BOARD_STRUCT_IMPLEMENTATION
#define WHITE		(+1)
#define BLACK		(-1)
#define NONE            0

typedef int CELL; 
typedef struct brd {
     int white_board;
     int black_board;
     int all_board;
     int white_ptr;
     int white_age[CELL_TO_ALIGN];
     int black_ptr;
     int black_age[CELL_TO_ALIGN];
} BRD;

typedef BRD BOARD[1];

typedef int PLAYER;

#define BOARD_SIZE_BYTES (sizeof(BRD))

#define board_switch_player(a) ((a) *=(-1))
#define board_other_player(a) ((a) * (-1))
#define board_is_White(c) (c > 0)
#define board_is_Black(c) (c < 0)

#define board_is_Free(b,c) (!(b->all_board & (1<<c)))

#endif

void board_reset(BOARD b);
CELL boardGetCell(BOARD b, int id);
void boardSetCell(BOARD b, int id, PLAYER p);
int board_is_aligned(BOARD b, PLAYER p);
int isWinningBoard(BOARD b, PLAYER p);
