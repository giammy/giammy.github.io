/* $Id: ttt-term.c,v 1.1 2000/11/19 11:10:48 giammy Exp $ */
/*
 * $Log: ttt-term.c,v $
 * Revision 1.1  2000/11/19 11:10:48  giammy
 * added a porting of TicTacTic in C
 *
 * Revision 1.1  2000/11/06 16:24:39  giammy
 * adding GUI to coenc0
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "ttt.h"
#include "ttt-board.h"

extern BOARD currentBoard;

int main(int argc, char **argv)
{
     srandom(time(NULL));

     board_reset(currentBoard);
     print_board(currentBoard);
     printf("\n\n");

     game();

}
