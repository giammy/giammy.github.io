#include <stdio.h>
#include <time.h>
#include <assert.h>

#include "ttt.h"
#include "ttt-board.h"

#define  LINUX 1
#define  V850 0


/*
 * Specific I/O
 */
#if LINUX
#define syslog printf
#endif

BOARD currentBoard;
PLAYER currentPlayer;

void print_board(BOARD b)
{
     int i, j, k = 0;
     for (i=0; i<BOARD_SIZE; i++) {
	  for (j=0; j<BOARD_SIZE; j++) {
	       CELL c = boardGetCell(b, k);
	       syslog("(%2d)%c ", c, 
		      board_is_White(c) ?
			 WHITE_CHAR:
			 (board_is_Black(c)?BLACK_CHAR:FREE_CHAR));
	       ++k;
	  }
	  syslog("\n");
     }
}

MOVE get_user_move(void)
{
     int next;
     for(;;) {
	  next = io_get_integer("Input your move [0-8]: ");
	  if ( (next >= 0 && next < BOARD_SIZE * BOARD_SIZE) &&
	       board_is_Free(currentBoard, next)) 
	       return next;
	  else
	       syslog("Illegal Move\n");
     }
}

int getRandomMove(BOARD b)
{
     int i;
/*TODO*/
     for (;;) {
	  i = random() % (BOARD_SIZE * BOARD_SIZE);
	  if (board_is_Free(b, i))
	       return i;
     }
}

VALUED_MOVE get_random_valued_move(BOARD b)
{
     VALUED_MOVE m;
     m.move = getRandomMove(b);
     m.value = 0;
     assert(m.move < BOARD_SIZE * BOARD_SIZE);
     return m;	  
}

VALUED_MOVE search( BOARD b, PLAYER p, 
		    int maxRecursion, int current_recursion, 
		    long alpha, long beta)
{
     VALUED_MOVE bestMove;
     VALUED_MOVE nextvm;
     BOARD newb;
     int win;

     win = isWinningBoard(b, p);
     if (win >= 0) {
	  assert(win < BOARD_SIZE * BOARD_SIZE);
	  bestMove.move = win;
	  bestMove.value = MAX_MOVE_VALUE - 2 * current_recursion;
	  return bestMove;
	  } 
     else if (current_recursion == maxRecursion)
	  return get_random_valued_move(b);
     else {
	  int a = alpha;
	  int currentId;
	  bestMove = get_random_valued_move(b);
	  for (currentId = 0; currentId < BOARD_SIZE*BOARD_SIZE; currentId++) {
	       if (!board_is_Free(b, currentId)) continue;
	       memcpy(newb, b, BOARD_SIZE_BYTES);
	       boardSetCell(newb, currentId, p);
	       nextvm = search(newb, board_other_player(p), 
			       maxRecursion, current_recursion+1,
			       -beta, -a);
	       if (-nextvm.value > a) {
		    a = -nextvm.value;
		    bestMove.move = currentId;
		    bestMove.value = a;
	       }
	       if (a > beta)
		    return bestMove;
	  }
	  return bestMove;
     }
}

MOVE get_next_move(BOARD b, PLAYER p)
{
     VALUED_MOVE m = search(b, p, RECURSION_LEVEL, 0, -60000, 60000);
     syslog("Select move %d\n", m.move);
     assert(m.move >= 0);
     assert(m.move < BOARD_SIZE * BOARD_SIZE);
     return m.move;
}

int game(void)
{
     MOVE next;
     int winner = NONE;
     currentPlayer = WHITE;

     while (!winner) {
	  if (currentPlayer == WHITE)
	       next = get_user_move();
	  else
	       next = get_next_move(currentBoard, currentPlayer);
	  boardSetCell(currentBoard, next, currentPlayer);
	  print_board(currentBoard);
	  syslog("\n\n");
	  board_switch_player(currentPlayer);

	  if (board_is_aligned(currentBoard, WHITE)) {
	       syslog("WHITE WINS!\n");
	       return 0;
	  } 
	  if (board_is_aligned(currentBoard, BLACK)) {
	       syslog("BLACK WINS!\n");
	       return 0;
	  }
     }
}
