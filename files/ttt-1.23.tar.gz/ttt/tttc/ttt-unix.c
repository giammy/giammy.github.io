/* $Id: ttt-unix.c,v 1.1 2000/11/19 11:10:49 giammy Exp $ */
/*
 * $Log: ttt-unix.c,v $
 * Revision 1.1  2000/11/19 11:10:49  giammy
 * added a porting of TicTacTic in C
 *
 * Revision 1.1  2000/11/06 16:24:39  giammy
 * adding GUI to coenc0
 *
 */
#include <stdio.h>

int io_get_integer(char *comment)
{
     char line[80];
     int n;

     for(;;) {
	  printf(comment);
	  fgets(line, sizeof(line), stdin);
	  if (sscanf(line, "%d", &n) != 1)
	       printf("Illegal input format\n");
	  else
	       return n;
     }
}
