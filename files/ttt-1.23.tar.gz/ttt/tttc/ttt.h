/* $Id: ttt.h,v 1.1 2000/11/19 11:10:49 giammy Exp $ */
/*
 * $Log: ttt.h,v $
 * Revision 1.1  2000/11/19 11:10:49  giammy
 * added a porting of TicTacTic in C
 *
 * Revision 1.1  2000/11/06 16:24:39  giammy
 * adding GUI to coenc0
 *
 */

#define BOARD_SIZE	3
#define CELL_TO_ALIGN	BOARD_SIZE
#define CELL_LIFE	CELL_TO_ALIGN
#define RECURSION_LEVEL 14
#define WHITE_CHAR      'O'
#define BLACK_CHAR      'X'
#define FREE_CHAR       '.'

#define MAX_MOVE_VALUE  100

typedef int MOVE;

typedef struct valuedMove {
     MOVE move;
     int value;
} VALUED_MOVE;


extern int io_get_integer(char *comment);
