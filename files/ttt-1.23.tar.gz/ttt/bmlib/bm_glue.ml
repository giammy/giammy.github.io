open Tk

type widget = Widget.widget

type 'a constructor = widget -> 'a
type widget_constructor = widget constructor

type 'a widget_join = (widget -> 'a) -> widget_constructor

type action = (unit -> unit) -> unit

type tkoptions = Tk.options list

(*
 * protect a showInterest---when something fails, declare no further
 * interest
 *)
let protect f arg =
  try
    f arg
  with Protocol.TkError _ -> raise Chatterbox.Bored

(*
 * shortcut for building pairs of widgets
 *)
let pair a b parent = (a parent, b parent)


(*
 * invoke K now and whenever language changes
 *)
let withTranslation msg k =
  let invoke () = k (Language.translate msg) in
  begin
    Language.showInterest (protect (fun _ -> invoke ()));
    invoke ();
  end

let withTranslationF msg k =
  let invoke () = k (Language.translate (msg ())) in
  begin
    Language.showInterest (protect (fun _ -> invoke ()));
    invoke ();
  end

(* default border options *)
let border_options =
  [BorderWidth (Pixels 2); Relief Groove]

let iota = 
  let rec loop l i =
    if (i = 0) then 
      l
    else loop ((i - 1) :: l) (i - 1)
  in loop []
