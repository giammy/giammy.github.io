open Configuration

type message = { 
    english: string;
    italiano: string
}

let sLanguage = intern "language"
let sItaliano = intern "italiano"
let sEnglish = intern "english"

let variable = Configuration.create sLanguage sEnglish
let showInterest = Configuration.showInterest variable

let translate s = 
  let x = Configuration.get variable in
  if eq x sItaliano then
    s.italiano
  else
    s.english
