open Tk
open Language
open Bm_glue

type style = Default | Windows

let makeWithOptions style options action parent =
  let b = Button.create parent options in
  let reconfigure txt backColor foreColor = 
    begin
      Button.configure b [Text txt];
      if (backColor <> "") then 
	try Button.configure b [Background (NamedColor backColor)]
	with _ -> ();
      if (foreColor <> "") then 
	try Button.configure b [Foreground (NamedColor foreColor)];
	with _ -> ();
    end
  in
  begin
    Button.configure b
      [Command (fun () -> action (fun () -> ()))];
    (b, reconfigure)
  end

let default_options = []

let make parent = makeWithOptions Default default_options parent
let makeWithBorder parent = makeWithOptions Default border_options parent

