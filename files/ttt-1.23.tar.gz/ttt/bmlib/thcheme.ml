(* Just for compatibility with major BMLIB: 
 * here I have not a Thcheme interpreter: 
 * what I need for the configuration file is 
 * in configuration.ml
 *)

let intern = Configuration.intern
