open Tk
open Language
open Bm_glue

(* label with no text, you have to manage it yourself *)
let makeWithOptions options parent =
  let l = Label.create parent options in
  let reconfigure s backColor foreColor = 
    begin
      Label.configure l [Text s];
      if (backColor <> "") then 
	try Label.configure l [Background (NamedColor backColor)]
	with _ -> ();
      if (foreColor <> "") then 
	try Label.configure l [Foreground (NamedColor foreColor)]
	with _ -> ();
    end in
  (l, reconfigure)

let default_options = []

let make parent = makeWithOptions default_options parent
let makeWithBorder parent = makeWithOptions border_options parent

