open Language
open Tk
open Bm_glue
open Configuration

let bindKill top =
  let winfoid = int_of_string (Winfo.id top) in
  bind top [[], Destroy]
    (BindExtend
       ([Ev_RootWindow], fun ei -> if (winfoid = ei.ev_RootWindow) then 
	 Tk.destroy top))

let make_aux title makeContents localTop =
  let contents = makeContents localTop in
  begin
    bindKill localTop;
    withTranslation title (Wm.title_set localTop);
    pack [contents] [Fill Fill_Both; Expand true; Side Side_Top];
    Focus.set localTop;
    localTop
  end

let makeWithPosition position title makeContents parent =
  let localTop = Toplevel.create parent [] in
  let _ = Wm.geometry_set localTop position in
  make_aux title makeContents localTop

let make title makeContents parent =
  let localTop = Toplevel.create parent [] in
  make_aux title makeContents localTop

let bindSize var p =
  let resize x = withString x (Wm.geometry_set p) in
  begin
    Configuration.withValue var resize;

    let winfoid = int_of_string (Winfo.id p) in
    bind p [[], Configure] 
      (BindExtend 
	 ([Ev_RootWindow; Ev_Height; Ev_Width;],
	  (fun ei ->
	    if (winfoid = ei.ev_RootWindow) then 
	      let geometry = String (Winfo.geometry p)
	      in
	      Configuration.set var geometry)));
  end

let makeResizable var title makeContents parent =
  let p = make title makeContents parent in
  begin
    bindSize var p;
    p;
  end

(* like make, but open main Tk widget (no parent) *)
let openTk var title makeContents =
  let top = Tk.openTk () in
  let w = make_aux title makeContents top in
  begin
    bindSize var top;
    Tk.mainLoop ();
    ()
  end
