open Tk
open Bm_glue

let default_options = []

let commonWithOptions packinfo options makeboth = 
  Bm_grid.makeWithOptions options packinfo [1.0]
    (fun f ->
      let (top, bot) = makeboth f in
      [[top]; [bot]])

let topExpandingWithOptions = commonWithOptions [1.0; 0.0]
let topExpanding parent = topExpandingWithOptions default_options parent
let topExpandingWithBorder parent =
  topExpandingWithOptions border_options parent

let bottomExpandingWithOptions = commonWithOptions [0.0; 1.0]
let bottomExpanding parent = bottomExpandingWithOptions default_options parent
let bottomExpandingWithBorder parent =
  bottomExpandingWithOptions border_options parent
