open Configuration
open Language
open Tk
open Bm_glue

let vTearOff = Configuration.create (intern "tear-off") True

type menuentry =
  | MenuEntry of (message * (unit -> unit))
  | MenuDisabled of message
  | MenuRadioButton of (message * Configuration.variable * value)
  | MenuCheckButton of (message * Configuration.variable)
  | MenuChoice of 
      (Language.message * Configuration.variable * (value list))
  | MenuSeparator

let withLabelTranslation m msg configure =
  let i = Number (Menu.index m Last) in
  withTranslation msg (fun x -> configure m i [Label x])
  
(* create a menu bar *)
let create parent data =
  let mbar = Frame.create parent [Relief Raised; BorderWidth (Pixels 2)] in
  let addMenu (buttonName, buttonOptions, side, menuEntries) =
    let oldMenu = ref None in
    let menuCreate b =
      let m = Menu.create b [] in
      begin
	pack [b] [Side side];
	Configuration.withValue vTearOff 
	  (protect
	     (fun x -> withBool x (fun x' -> Menu.configure m [TearOff x'])));
	List.iter 
	  (function 
	    | MenuEntry (name, cmd) -> 
		Menu.add_command m ([Command cmd]);
		withLabelTranslation m name Menu.configure_command
	    | MenuRadioButton (name, var, value) -> 
		Menu.add_radiobutton m 
		  [Variable (Configuration.make_textVariable var);
		   Value (Configuration.write value);
		   Command (fun () -> Configuration.set var value)];
		withLabelTranslation m name Menu.configure_radiobutton
	    | MenuCheckButton (name, var) -> 
		let tv = Configuration.make_textVariable var in
		Menu.add_checkbutton m 
		  [Variable tv;
		   OnValue "#t";
		   OffValue "#f";
		   Command 
		     (fun () ->
		       if (Textvariable.get tv) = "#f" then
			 Configuration.set var False
		       else
			 Configuration.set var True)
		 ];
		withLabelTranslation m name Menu.configure_checkbutton
	    | MenuDisabled name -> 
		Menu.add_command m ([State Disabled]);
		withLabelTranslation m name Menu.configure_command
	    | MenuChoice (name, var, choices) ->
		let cascade = Menu.create m [TearOff false] in
		begin
		  List.iter (fun choice ->
		    Menu.add_radiobutton cascade
		      [Variable (Configuration.make_textVariable var);
		       Value (Configuration.display choice);
		       Label (Configuration.display choice);
		       Command (fun () -> Configuration.set var choice)])
		    choices;
		  Menu.add_cascade m [Menu cascade];
		  withLabelTranslation m name Menu.configure_command;
		end
	    | MenuSeparator -> Menu.add_separator m)
	  menuEntries;
	begin match !oldMenu with
	| None -> ()
	| Some m -> Tk.destroy m
	end;
	oldMenu := Some m;
	Menubutton.configure b [Menu m];

	withTranslation buttonName
	  (fun x -> Menubutton.configure b [Text x]);
      end
    in
    let b = Menubutton.create mbar buttonOptions in
    menuCreate b
  in begin
    List.iter addMenu data;
    mbar
  end

