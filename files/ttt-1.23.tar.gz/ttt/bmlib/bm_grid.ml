open Tk
open Bm_glue

let enumerate l = iota (List.length l)

let makeWithOptions1 options makeall parent =
  let f = Bm_frame.makeWithOptions options parent in
  let (rowweights, colweights, ll) = makeall f in
  begin
    List.iter2 (fun w r ->
      Grid.row_configure f r [Weight w])
      rowweights (enumerate rowweights);

    List.iter2 (fun w c ->
      Grid.column_configure f c [Weight w])
      colweights (enumerate colweights);
    
    List.iter2 (fun row r ->
      List.iter2 (fun w c ->
	grid [w] [In f; Row r; Column c; Sticky "news"])
	row (enumerate row))
      ll (enumerate ll);
    
    f;
  end

let makeWithOptions options rowweights colweights makeall =
  makeWithOptions1 options (fun f -> (rowweights, colweights, makeall f))

let default_options = []
let make = makeWithOptions default_options
