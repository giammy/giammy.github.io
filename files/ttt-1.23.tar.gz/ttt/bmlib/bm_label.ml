open Tk
open Language
open Bm_glue

let make msg parent =
  let (l, reconfigure) = Bm_emptylabel.make parent in
  begin 
    withTranslation msg (fun s -> reconfigure s "" "");
    l;
  end

