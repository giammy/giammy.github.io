open Bm_glue
open Tk

let makeWithOptions options parent = Frame.create parent options

let default_options = []

let make parent = makeWithOptions default_options parent
let makeWithBorder parent = makeWithOptions border_options parent
