open Tk
open Language
open Bm_glue

let ignoreExn f b =
  try
    f b
  with
    Protocol.TkError _ -> ()

let make_command bs action = fun () ->
  begin
    List.iter 
      (ignoreExn (fun b -> Button.configure b [State Disabled]))
      bs;
    action (fun () -> 
      List.iter 
	(ignoreExn (fun b -> Button.configure b [State Normal]))
	bs)
  end
  
let makeWithOptions options msg_action_l parent =
  let bs = List.map (fun _ -> Button.create parent options) msg_action_l in
  begin
    List.iter2 (fun b (msg, showInterest, action) ->
      begin
	Button.configure b [Command (make_command bs action)];
	withTranslation msg (fun s -> Button.configure b [Text s]);
	match showInterest with
	  None -> ()
	| Some s -> s (fun () -> Button.invoke b)
      end)
      bs
      msg_action_l;
    bs;
  end
      
let default_options = []
let make msg = makeWithOptions default_options msg
