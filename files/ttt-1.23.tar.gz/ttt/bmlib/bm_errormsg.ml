open Tk
open Language
open Bm_glue

let join = Bm_vbox.topExpandingWithBorder

let makeWithTitle titlemsg labelmsg action parent =
  let mainParent = Winfo.toplevel parent in
  let x = Winfo.x mainParent in
  let y = Winfo.y mainParent in
  let width = Winfo.width mainParent in
  let height = Winfo.height mainParent in
  let geometry = ("+" ^ (string_of_int (x + width / 3)) ^ 
		  "+" ^ (string_of_int (y + height / 3)))  in
  Bm_toplevel.makeWithPosition geometry
    titlemsg
    (fun fTop ->
      join 
	(fun f ->
	  let label = Bm_label.make labelmsg f
	  and button =
	    Bm_button.make
	      { english = "OK"; italiano = "OK" } 
	      (fun k -> Tk.destroy fTop; action (); k ())
	      f
	  in (label, button))
	fTop) parent
       
let make = makeWithTitle { english = "Error"; italiano = "Errore" }
