open Chatterbox

exception Error

type value =
  | Integer of int
  | Flonum of float
  | String of string
  | Symbol of string
  | True
  | False
  | Unspecified

type variable = {
    (* name of the variable (a thcheme symbol) *)
    name: value;   

    (* value of the variable (a thcheme value) *)
    value: value ref;

    showInterest: value interested;
    notify: value notifier;

    textvar: Textvariable.textVariable option ref;
} 

let configuration = ref []

let eq = (==)

module Symbol : sig
  val intern : string -> value
  val to_string : value -> string

  val sQuote : value
end = struct
  module HashString =
    struct
      type t = string
      let equal = (=)
      let hash = Hashtbl.hash
    end

  module HashtblString = Hashtbl.Make(HashString)
      
  let obarray = HashtblString.create 71
      
  let intern s =
    try
      HashtblString.find obarray s 
    with
      Not_found ->
	let newsym = Symbol s
	in begin
	  HashtblString.add obarray s newsym;
	  newsym;
	end

  let to_string = function
    | Symbol s -> s
    | x -> failwith "Symbol.to_string"

  let sQuote = intern "quote"
end

let intern = Symbol.intern

let get var =
  !(var.value)

let rec equal a b =
  eq a b || 
  match (a, b) with
    (Integer x, Integer y) -> x = y
  | (Flonum x, Flonum y) -> x = y
  | (String x, String y) -> x = y
  | _ -> false

let set variable value =
  if not (equal value (get variable)) then
    begin
      variable.value := value;
      variable.notify value
    end

let writeVar value =
  match value with
  | Integer x -> (string_of_int x)
  | Flonum x -> (string_of_float x)
  | String x -> x
  | (Symbol _) as x -> Symbol.to_string x
  | True -> "#t"
  | False -> "#f"
  | Unspecified -> "#u"

let withInteger value k =
  match value with
  | Integer x -> k x
  | _ -> failwith "Configuration:withInteger"

let withString value k =
  match value with
  | String x -> k x
  | _ -> failwith "Configuration:withString"

let withBool value k =
  match value with
  | False -> k false
  | _ -> k true

let showInterest var = var.showInterest

let withValue a k =
  begin
    a.showInterest k;
    k (get a)
  end
	
let write = writeVar

let display s = 
  match s with 
  | String x -> ("\"" ^ x ^ "\"") 
  | Symbol _ as x -> ( "'" ^ (writeVar x))
  | _ -> writeVar s

let rec lookup name = function
  | [] -> None
  | a :: b ->
      if (a.name = name) then
	Some a
      else
	lookup name b

let defvar always_set name value =
  match lookup name !configuration with
    Some a -> 
      if (always_set) then set a value;
      a
  | None ->
      let (showInterest, notify) = Chatterbox.create () in
      let a = { 
	name = name;
	value = ref Unspecified;
	showInterest = showInterest;
	notify = notify;
	textvar = ref None;
      }	
      in begin
	configuration := a :: !configuration;
	set a value;
	a
      end

(* create a variable.  If already defined, don't change its value *)
let create = defvar false
  
let make_textVariable a = 
  match !(a.textvar) with
  | Some x -> x
  | None ->
      let x = Textvariable.create () in
      let setTextVar v = Textvariable.set x (write v) in (* xxx ??? *)
      begin
	a.textvar := Some x;
	a.showInterest setTextVar;
	setTextVar (get a); (* update the value of the text variable *)
	x
      end


(* routine to parse configuration file *)

let eol = function
  | '\n' | '\r' -> true
  | _ -> false

let is_space = function
  | ' ' | '\t' -> true
  | x -> eol x

let rec many p = parser
    [< a = p; b = many p>] -> a :: b
  | [< >] -> []

let rec many1 p = parser
  | [< a = p; b = many p >] -> a :: b

let optional p = parser
  | [< a = p >] -> a
  | [< >] -> ()

let space = parser 
    [< 'c when is_space c >] -> ()

let empty = parser
  | [< 'a >] -> false
  | [< >] -> true

let comment = 
  let noneol = parser 
      [< 'c when (not (eol c)) >] -> c
  in parser
      [< '';'; _ = many noneol; >] -> ()

let rec skip_ws = parser
  | [< _ = space; _ = skip_ws >] -> ()
  | [< _ = comment; _ = skip_ws >] -> ()
  | [< >] -> ()

let rec ignoreSpaces p = parser
    [< _ = space; a = ignoreSpaces p >] -> a
  | [< _ = comment; a = ignoreSpaces p >] -> a
  | [< b >] -> p b

let is_ident_or_number_character = function
  | '(' | ')' -> false
  | x -> not (is_space x)

let ident_or_number_character = parser
  | [< 'c when is_ident_or_number_character c >] -> c

let is_float x = 
  let digit = parser 
    | [< ''0'..'9' >] -> ()
  in
  let sign = parser 
    | [< ''+' >] -> () 
    | [< ''-' >] -> () 
  in 
  try
    match Stream.of_string x with parser
    | [< _ = optional sign; 
	_ = many1 digit;
	_ = optional 
	  (parser [< ''.'; _ = many digit >] -> ());
	_ = optional 
	  (parser [< ''e'; _ = optional sign; _ = many1 digit >] -> ());
	b = empty >] -> b
  with Stream.Error _ -> false

let is_integer x =
  let l = String.length x in
  let rec loop i =
    if (i >= l) then true
    else match String.unsafe_get x i with
      '0'..'9' -> loop (i + 1)
    |	_ -> false
  in
  if l = 0 then false
  else match String.unsafe_get x 0 with
  | '+' | '-' -> loop 1
  | _ -> loop 0
    
let parse_ident_or_number x = x	
  
let rec read x = 
  (ignoreSpaces (parser
    | [< 
	''('; 
	_ = skip_ws;
	ig = many1 ident_or_number_character; 
	_ = skip_ws;
	name = many1 ident_or_number_character; 
	_ = skip_ws;
	value = many1 ident_or_number_character;  
	_ = skip_ws;
	'')'>] -> (true, name, value)
    | [< 'a >] -> raise Error
    | [< >] -> (false, [], []))) 
    x

let string_implode x =
  let l = List.length x in
  let s = String.create l in
  let rec loop i = function
    |	[] -> ()
    |	a :: b ->
	String.unsafe_set s i a;
	loop (i+1) b
  in begin
    loop 0 x;
    s;
  end

let unquoteIdent s =
  let l = String.length s in 
  if l = 0 then
    s 
  else
    begin
      if (String.get s 0 = '\'') then
	String.sub s 1 (l-1)
      else
	s
    end

(* delete delimiting '"' from string, if they are present *) 
let unquote string =
  let quote = '"' in
  let unquote_first s =
    let l = String.length s in
    if (l >= 1 && (String.get s 0 = quote)) then
      String.sub s 1 (l-1)
    else
      s
  and unquote_last s =
    let l = String.length s in
    if (l >= 1 && (String.get s (l-1)) = quote) then
      String.sub s 0 (l-1)
    else
      s
  in
  unquote_first (unquote_last string)

let getValue s =
  if (String.get s 0) = '#' then
    begin
      if (String.get s 1) = 't' then
	True
      else
	False
    end
  else 
    begin
      try
	Integer (int_of_string s)
      with _ -> 
	begin
	  if (String.get s 0) = '\'' then
	    let s = (unquote s) in
	    let l = String.length s in
	    intern (String.sub s 1 (l-1));
	  else
	    String (unquote s);
	end
    end

let load stream =
  let rec loop () =
    let (noteof, name, value) = read stream in
    begin
      if noteof then
	let gname = intern (unquoteIdent (string_implode name)) in 
	let gvalue = getValue (string_implode value) in
	let _ = defvar true gname gvalue in
	loop ()
      else
	()
    end
  in loop ()

(* routines to read/write configuration files *)
type pathname = 
  | Absolute of string                (* absolute path *)
  | ExecRelative of string            (* relative to executable *)
  | EnvRelative of string * string    (* relative to environment variable *)

let exec_path () = 
  let s = Filename.dirname (Array.get Sys.argv 0)
  in unquote s

let toAbsolute = function
  | Absolute x -> x
  | ExecRelative x -> (exec_path ()) ^ x
  | EnvRelative (v, x) -> (Sys.getenv v) ^ x

let rec read path setFilename =
  match path with
  | [] -> ()
  | file :: rest ->
      try
	let name = toAbsolute file in
	let ichan = open_in name in
	let istream = Stream.of_channel ichan in
	begin
	  load istream;
	  close_in ichan;
	  setFilename name;
	end
      with Sys_error _ -> read rest setFilename

let dump_var ochan var =
  let s =
    "(define-property '" ^ (write var.name) ^ " " ^ (display (get var)) ^ ")\n" in 
  output_string ochan s
						     
let dump vConfFile = 
  try
    withString (get vConfFile) (fun name ->
      let ochan = open_out name in
      begin
	List.iter (dump_var ochan) !configuration;
	close_out ochan;
      end)
  with Sys_error _ -> raise Error

let booted = ref false
let boot path setFilename = 
  begin
    if not !booted then
      begin
	booted := true;
	read path setFilename;
      end
  end
