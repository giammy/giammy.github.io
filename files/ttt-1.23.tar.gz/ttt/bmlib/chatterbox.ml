exception Bored
type 'a interested = ('a -> unit) -> unit
and 'a notifier = 'a -> unit

let create () =
  let interested = ref [] in
  let showInterest f = interested := f :: !interested; () in
  let notify args =
    let rec loop l = function
      |	[] -> interested := l
      |	f :: x ->
	  try
	    f args;
	    loop (f :: l) x
	  with Bored -> loop l x
    in
    loop [] !interested;
  in (showInterest, notify)

