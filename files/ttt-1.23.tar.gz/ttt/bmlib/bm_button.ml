open Tk
open Language
open Bm_glue

let makeWithOptions options msg action parent =
  List.hd (Bm_buttons.makeWithOptions options [(msg, None, action)] parent)

let make msg action parent =
  List.hd (Bm_buttons.make [(msg, None, action)] parent)

